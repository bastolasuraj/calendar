<?php
// Database configuration and connection
require 'vendor/autoload.php'; // Composer's autoloader

class Database {
    private static $instance = null;
    private $client;
    private $db;

    private function __construct() {
        // Your MongoDB connection string
        $mongoUri = "mongodb+srv://bastolasuraj:kAMnlKP385wAhtq0@cluster0.iyow4fd.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
        try {
            $this->client = new MongoDB\Client($mongoUri);
            $this->db = $this->client->selectDatabase('calendarApp'); // Select your database
        } catch (Exception $e) {
            die("Database connection failed: " . $e->getMessage());
        }
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->db;
    }
}
