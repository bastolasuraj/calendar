<?php
// Main entry point for the application (Front Controller)

// Start the session for tracking login state
session_start();

// Require necessary files
require_once 'config/database.php';
require_once 'models/Booking.php';
require_once 'models/User.php'; // Add the new User model

// Basic Routing
$url = isset($_GET['url']) ? rtrim($_GET['url'], '/') : 'book';
$url = filter_var($url, FILTER_SANITIZE_URL);
$urlParts = explode('/', $url);

// Determine the controller
$controllerName = !empty($urlParts[0]) ? ucfirst($urlParts[0]) . 'Controller' : 'BookController';
$controllerFile = 'controllers/' . $controllerName . '.php';

if (file_exists($controllerFile)) {
    require_once $controllerFile;
    $controller = new $controllerName();

    // Determine the method/action
    $action = isset($urlParts[1]) ? $urlParts[1] : 'index';

    // Check if the method exists in the controller
    if (method_exists($controller, $action)) {
        // Call the method, passing any additional URL parts as parameters
        $params = array_slice($urlParts, 2);
        call_user_func_array([$controller, $action], $params);
    } else {
        // Handle 404 - Method not found
        echo "404 - Page Not Found";
    }
} else {
    // Handle 404 - Controller not found
    echo "404 - Page Not Found";
}
