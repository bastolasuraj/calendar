<?php
// Controller for the admin dashboard and authentication

// Add the Twilio SDK's autoloader
require_once 'vendor/autoload.php';
use Twilio\Rest\Client;

class AdminController {

    public function index() {
        if (isset($_SESSION['user_id'])) {
            $booking = new Booking();
            $allBookings = $booking->getAllBookings();
            require 'views/admin/index.php';
            return;
        }
        $user = new User();
        if ($user->hasAdminUser()) {
            header('Location: /cal/admin/login');
        } else {
            header('Location: /cal/admin/register');
        }
        exit;
    }

    public function updateStatus($accessCode = '', $status = '') {
        if (!isset($_SESSION['user_id'])) {
            header('Location: /cal/admin/login');
            exit;
        }

        if (empty($accessCode) || empty($status)) {
            header('Location: /cal/admin?error=missingdata');
            exit;
        }

        $bookingModel = new Booking();
        $booking = $bookingModel->getBookingByAccessCode($accessCode);

        if ($booking && $bookingModel->updateBookingStatus($accessCode, $status)) {
            // Send SMS Notification
            $this->sendSmsNotification($booking, $status);
            header('Location: /cal/admin?success=statusupdated');
        } else {
            header('Location: /cal/admin?error=updatefailed');
        }
        exit;
    }

    // --- UPDATED: Helper function to send SMS via Twilio ---
    private function sendSmsNotification($booking, $status) {
        if (empty($booking['phone'])) {
            return;
        }

        // --- Your Final Twilio Credentials ---
        $accountSid = "ACc8d7dab5df61d4a5fdf58801c8a3638c";
        $authToken = "9e824de7fb6a0b898b3c7365d38b695b";
        $messagingServiceSid = "MGcd87d9a60f9caaa24212fc122529e52e";

        // Standardize the user's phone number
        $numericPhone = preg_replace('/[^0-9]/', '', $booking['phone']);
        if (strlen($numericPhone) >= 10) {
            $toPhoneNumber = '+1' . substr($numericPhone, -10);
        } else {
            return; // Not a valid number, so we don't send.
        }

        $date = $booking['booking_datetime']->toDateTime()->format('M d, Y \a\t g:i A');
        $messageBody = '';

        if ($status === 'approved') {
            $messageBody = "Your booking for {$date} has been confirmed! Your access code is {$booking['access_code']}.";
        } elseif ($status === 'rejected') {
            $messageBody = "Unfortunately, your booking request for {$date} has been rejected. Please contact us for more details.";
        }

        if (!empty($messageBody)) {
            try {
                $client = new Client($accountSid, $authToken);
                $client->messages->create(
                    $toPhoneNumber,
                    [
                        // Using Messaging Service SID instead of a 'from' number
                        'messagingServiceSid' => $messagingServiceSid,
                        'body' => $messageBody
                    ]
                );
            } catch (Exception $e) {
                // You can log the error if sending fails, but we won't show it to the user
                // error_log('Twilio Error: ' . $e->getMessage());
            }
        }
    }

    public function login() {
        if (isset($_SESSION['user_id'])) { header('Location: /cal/admin'); exit; }
        require 'views/admin/login.php';
    }

    public function register() {
        $user = new User();
        if ($user->hasAdminUser()) { header('Location: /cal/admin/login'); exit; }
        require 'views/admin/register.php';
    }

    public function store() {
        $user = new User();
        if ($user->hasAdminUser()) { header('Location: /cal/admin/login'); exit; }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email']);
            $password = $_POST['password'];
            if ($user->register($email, $password)) {
                header('Location: /cal/admin/login?registered=1');
            } else {
                header('Location: /cal/admin/register?error=1');
            }
        }
    }

    public function authenticate() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email']);
            $password = $_POST['password'];
            $userModel = new User();
            $user = $userModel->login($email, $password);
            if ($user) {
                $_SESSION['user_id'] = (string)$user['_id'];
                $_SESSION['user_email'] = $user['email'];
                header('Location: /cal/admin');
            } else {
                header('Location: /cal/admin/login?error=1');
            }
        }
    }

    public function logout() {
        session_unset();
        session_destroy();
        header('Location: /cal/admin/login');
        exit;
    }
}
