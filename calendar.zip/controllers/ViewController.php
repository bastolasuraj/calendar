<?php
// Controller for viewing and managing bookings

class ViewController {

    // --- FIX: This method now correctly defines $publicBookings before loading the view ---
    public function index() {
        $booking = new Booking();
        // This variable holds the approved bookings for the view page
        $publicBookings = $booking->getPublicBookings();
        require 'views/view/index.php';
    }

    public function find() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $accessCode = trim($_POST['access_code']);
            if (!empty($accessCode)) {
                header('Location: /cal/view/details/' . $accessCode);
            } else {
                header('Location: /cal/view?error=notfound');
            }
        } else {
            header('Location: /cal/view');
        }
    }

    public function details($accessCode = '') {
        if (empty($accessCode)) { header('Location: /cal/view'); exit; }
        $bookingModel = new Booking();
        $booking = $bookingModel->getBookingByAccessCode($accessCode);
        if ($booking) {
            require 'views/view/details.php';
        } else {
            header('Location: /cal/view?error=notfound');
        }
    }

    public function update() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $accessCode = trim($_POST['access_code']);
            $newDateTime = trim($_POST['booking_datetime']);
            $bookingModel = new Booking();
            $success = $bookingModel->updateBooking($accessCode, $newDateTime);
            if ($success) {
                // When a user updates their own booking, its status becomes pending again.
                // We also add a query parameter to show a message on the details page.
                header('Location: /cal/view/details/' . $accessCode . '?success=1&status=pending');
            } else {
                header('Location: /cal/view/details/' . $accessCode . '?error=updatefailed');
            }
        } else {
            header('Location: /cal/view');
        }
    }
}
