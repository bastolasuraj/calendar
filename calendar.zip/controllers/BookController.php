<?php
// Controller for handling the booking process

class BookController {
    public function index() {
        require 'views/book/index.php';
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $laptopTag = trim($_POST['laptop_tag']);
            $email = trim($_POST['email']);
            $phone = trim($_POST['phone']); // Get a phone number
            $bookingDateTime = trim($_POST['booking_datetime']);

            $booking = new Booking();
            // Pass a phone number to the createBooking method
            $accessCode = $booking->createBooking($laptopTag, $email, $phone, $bookingDateTime);

            if ($accessCode) {
                require 'views/book/success.php';
            } else {
                header('Location: /cal/book?error=1');
            }
        } else {
            header('Location: /cal/book');
        }
    }

    public function getAvailableTimes($date = '') {
        if (empty($date)) {
            echo json_encode(['error' => 'Date is required.']);
            return;
        }
        if (!DateTime::createFromFormat('Y-m-d', $date)) {
            echo json_encode(['error' => 'Invalid date format.']);
            return;
        }
        header('Content-Type: application/json');
        $booking = new Booking();
        $availableSlots = $booking->getAvailableSlotsForDate($date);
        echo json_encode($availableSlots);
    }
}
