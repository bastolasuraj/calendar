<?php require_once 'views/templates/header.php'; ?>

<div class="card shadow-sm">
    <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
        <h2 class="h4 mb-0">Admin Dashboard - All Bookings</h2>
    </div>
    <div class="card-body">
        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success">Booking status updated successfully.</div>
        <?php endif; ?>
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-danger">Could not update booking status.</div>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle">
                <thead class="table-dark">
                <tr>
                    <th>Email & Phone</th>
                    <th>Laptop Tag</th>
                    <th>Booking Date & Time</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($allBookings as $booking):
                    $status = $booking['status'] ?? 'pending';
                    $statusClass = '';
                    switch ($status) {
                        case 'approved': $statusClass = 'text-success'; break;
                        case 'rejected': $statusClass = 'text-danger'; break;
                        default: $statusClass = 'text-warning'; break;
                    }
                    ?>
                    <tr>
                        <td>
                            <?php echo htmlspecialchars($booking['email']); ?><br>
                            <small class="text-muted"><?php echo htmlspecialchars($booking['phone'] ?? 'N/A'); ?></small>
                        </td>
                        <td><?php echo htmlspecialchars($booking['laptop_tag']); ?></td>
                        <td><?php echo date('Y-m-d H:i', $booking['booking_datetime']->toDateTime()->getTimestamp()); ?></td>
                        <td>
                            <strong class="<?php echo $statusClass; ?>"><?php echo ucfirst(htmlspecialchars($status)); ?></strong>
                        </td>
                        <td>
                            <?php if ($status === 'pending'): ?>
                                <a href="/cal/admin/updateStatus/<?php echo $booking['access_code']; ?>/approved" class="btn btn-sm btn-success">Approve</a>
                                <a href="/cal/admin/updateStatus/<?php echo $booking['access_code']; ?>/rejected" class="btn btn-sm btn-danger">Reject</a>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (iterator_count($allBookings) === 0): ?>
                    <tr>
                        <td colspan="5" class="text-center">No bookings found.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once 'views/templates/footer.php'; ?>
