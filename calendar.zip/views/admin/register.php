<?php require_once 'views/templates/header.php'; ?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-header bg-dark text-white">
                <h2 class="h4 mb-0">Create Admin Account</h2>
            </div>
            <div class="card-body">
                <p class="text-muted">Create the first administrator account. This page will be disabled after the first user is created.</p>
                <?php if (isset($_GET['error'])): ?>
                    <div class="alert alert-danger">Could not create an account. Please check your inputs.</div>
                <?php endif; ?>

                <form action="/cal/admin/store" method="POST">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Create Account</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'views/templates/footer.php'; ?>
