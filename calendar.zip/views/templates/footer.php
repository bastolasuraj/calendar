</div> <!-- /container -->

<footer class="footer">
    <div class="container">
        <span class="text-muted">Calendar App &copy; 2024</span>
    </div>
</footer>

<!-- Custom Calendar CSS -->
<style>
    #calendar-container {
        border-radius: 0.5rem;
        padding: 1rem;
        background-color: #fff;
        border: 1px solid #dee2e6;
    }
    .calendar-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1rem;
    }
    .calendar-header button {
        border: none;
        background: transparent;
        font-size: 1.5rem;
        cursor: pointer;
    }
    #calendar-month-year {
        font-size: 1.2rem;
        font-weight: 600;
    }
    .calendar-grid {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        gap: 5px;
    }
    .calendar-day, .calendar-weekday {
        text-align: center;
        padding: 0.5rem 0;
    }
    .calendar-weekday {
        font-weight: 600;
        color: #6c757d;
    }
    .calendar-day {
        cursor: pointer;
        border-radius: 50%;
        transition: background-color 0.2s;
    }
    .calendar-day:not(.disabled):hover {
        background-color: #e9ecef;
    }
    .calendar-day.selected {
        background-color: #0d6efd;
        color: white;
    }
    .calendar-day.disabled {
        color: #adb5bd;
        cursor: not-allowed;
        text-decoration: line-through;
    }
    .calendar-day.empty {
        cursor: default;
    }
</style>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Flatpickr JS (still needed for the update page) -->
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const calendarContainer = document.getElementById('calendar-container');
        if (calendarContainer) {
            const timeSlotsWrapper = document.getElementById('time-slots-wrapper');
            const timeSlotsDiv = document.getElementById('time-slots');
            const noSlotsMessage = document.getElementById('no-slots-message');
            const hiddenDateTimeInput = document.getElementById('booking_datetime');
            const submitBtn = document.getElementById('submitBtn');
            const selectedDateDisplay = document.getElementById('selected-date-display');

            let currentDate = new Date();
            currentDate.setDate(1);

            // --- New JS Holiday Checker ---
            function isHoliday(date) {
                const year = date.getFullYear();
                const month = date.getMonth(); // 0-11
                const day = date.getDate();
                const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

                const goodFridays = ['2025-04-18', '2026-04-03', '2027-03-26'];
                if (goodFridays.includes(dateStr)) return true;

                if ((month === 0 && day === 1) || // New Year's
                    (month === 6 && day === 1) || // Canada Day
                    (month === 11 && day === 25) || // Christmas
                    (month === 11 && day === 26)) { // Boxing Day
                    return true;
                }

                // Victoria Day (Monday preceding May 25)
                if (month === 4) { // May
                    const vicDayTest = new Date(year, 4, 25);
                    const dayOfWeek = vicDayTest.getDay(); // 0=sun, 1=mon...
                    const prevMonday = 25 - (dayOfWeek === 0 ? 6 : dayOfWeek - 1);
                    if (day === prevMonday) return true;
                }

                // Family Day (Third Monday in February)
                if (month === 1) { // February
                    const firstDay = new Date(year, 1, 1).getDay();
                    const thirdMonday = 1 + (8 - firstDay) % 7 + 14;
                    if (day === thirdMonday) return true;
                }

                // Labour Day (First Monday in September)
                if (month === 8) {
                    const firstDay = new Date(year, 8, 1).getDay();
                    const firstMonday = 1 + (8 - firstDay) % 7;
                    if (day === firstMonday) return true;
                }

                // Thanksgiving (Second Monday in October)
                if (month === 9) {
                    const firstDay = new Date(year, 9, 1).getDay();
                    const secondMonday = 1 + (8 - firstDay) % 7 + 7;
                    if (day === secondMonday) return true;
                }

                // Statutory Canada Day
                if (month === 6) {
                    const dayOfWeek = new Date(year, 6, 1).getDay();
                    if ((dayOfWeek === 6 && day === 3) || (dayOfWeek === 0 && day === 2)) return true;
                }

                return false;
            }

            function generateCalendar(date) {
                calendarContainer.innerHTML = '';
                const month = date.getMonth();
                const year = date.getFullYear();
                const today = new Date();
                today.setHours(0,0,0,0);

                const daysInMonth = new Date(year, month + 1, 0).getDate();
                const startingDay = new Date(year, month, 1).getDay();

                const header = document.createElement('div');
                header.className = 'calendar-header';
                header.innerHTML = `
                <button id="prev-month">&lt;</button>
                <span id="calendar-month-year">${date.toLocaleString('default', { month: 'long' })} ${year}</span>
                <button id="next-month">&gt;</button>
            `;
                calendarContainer.appendChild(header);

                const grid = document.createElement('div');
                grid.className = 'calendar-grid';

                ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].forEach(day => {
                    const weekday = document.createElement('div');
                    weekday.className = 'calendar-weekday';
                    weekday.textContent = day;
                    grid.appendChild(weekday);
                });

                for (let i = 0; i < startingDay; i++) {
                    grid.appendChild(document.createElement('div')).className = 'calendar-day empty';
                }

                // --- Updated Day Generation Loop ---
                for (let i = 1; i <= daysInMonth; i++) {
                    const dayCell = document.createElement('div');
                    dayCell.className = 'calendar-day';
                    dayCell.textContent = i;
                    dayCell.dataset.date = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;

                    const cellDate = new Date(year, month, i);
                    const dayOfWeek = cellDate.getDay();

                    // Disable past days, weekends (Sat/Sun), and holidays
                    if (cellDate < today || dayOfWeek === 0 || dayOfWeek === 6 || isHoliday(cellDate)) {
                        dayCell.classList.add('disabled');
                    }
                    grid.appendChild(dayCell);
                }

                calendarContainer.appendChild(grid);

                document.getElementById('prev-month').addEventListener('click', () => {
                    currentDate.setMonth(currentDate.getMonth() - 1);
                    generateCalendar(currentDate);
                });
                document.getElementById('next-month').addEventListener('click', () => {
                    currentDate.setMonth(currentDate.getMonth() + 1);
                    generateCalendar(currentDate);
                });

                grid.addEventListener('click', handleDateClick);
            }

            function handleDateClick(e) {
                const target = e.target;
                if (!target.classList.contains('calendar-day') || target.classList.contains('disabled') || target.classList.contains('empty')) {
                    return;
                }
                document.querySelectorAll('.calendar-day').forEach(day => day.classList.remove('selected'));
                target.classList.add('selected');
                const dateStr = target.dataset.date;
                timeSlotsDiv.innerHTML = '';
                noSlotsMessage.style.display = 'none';
                timeSlotsWrapper.style.display = 'block';
                hiddenDateTimeInput.value = '';
                submitBtn.disabled = true;
                selectedDateDisplay.textContent = new Date(dateStr + 'T00:00:00').toLocaleDateString('en-us', { weekday:"long", year:"numeric", month:"long", day:"numeric"});
                fetch(`/cal/book/getAvailableTimes/${dateStr}`)
                    .then(response => response.json())
                    .then(slots => {
                        if (slots.length > 0) {
                            slots.forEach(slot => {
                                const btn = document.createElement('button');
                                btn.type = 'button';
                                btn.className = 'btn btn-outline-primary';
                                btn.textContent = slot;
                                btn.dataset.time = slot;
                                timeSlotsDiv.appendChild(btn);
                            });
                        } else {
                            noSlotsMessage.textContent = 'No available time slots for this date.';
                            noSlotsMessage.style.display = 'block';
                        }
                    });
            }

            timeSlotsDiv.addEventListener('click', function(e) {
                if (e.target.tagName === 'BUTTON') {
                    document.querySelectorAll('#time-slots button').forEach(btn => btn.classList.remove('active', 'btn-primary'));
                    e.target.classList.add('active', 'btn-primary');
                    const selectedDate = document.querySelector('.calendar-day.selected').dataset.date;
                    const selectedTime = e.target.dataset.time;
                    hiddenDateTimeInput.value = `${selectedDate} ${selectedTime}`;
                    submitBtn.disabled = false;
                }
            });

            generateCalendar(currentDate);
        }

        flatpickr(".datetime-picker", {
            enableTime: true,
            dateFormat: "Y-m-d H:i",
            minDate: "today",
            time_24hr: true
        });

        const bookingForm = document.getElementById('bookingForm');
        if(bookingForm) {
            bookingForm.addEventListener('submit', function(event) {
                const laptopTag = document.getElementById('laptop_tag').value;
                const email = document.getElementById('email').value;
                const dateTime = document.getElementById('booking_datetime').value;
                if (!laptopTag || !email || !dateTime) {
                    alert('Please fill out all fields and select a date and time.');
                    event.preventDefault();
                }
            });
        }
    });
</script>
</body>
</html>
