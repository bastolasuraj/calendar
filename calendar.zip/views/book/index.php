<?php require_once 'views/templates/header.php'; ?>

<div class="card shadow-sm">
    <div class="card-header bg-primary text-white">
        <h2 class="h4 mb-0">Book a New Session</h2>
    </div>
    <div class="card-body">
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-danger">The selected time slot is no longer available or your inputs were invalid. Please try again.</div>
        <?php endif; ?>

        <form id="bookingForm" action="/cal/book/create" method="POST">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="laptop_tag" class="form-label">Laptop Tag</label>
                        <input type="text" class="form-control" id="laptop_tag" name="laptop_tag" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <!-- New Phone Number Field -->
                    <div class="mb-3">
                        <label for="phone" class="form-label">Phone Number (for SMS alerts)</label>
                        <input type="tel" class="form-control" id="phone" name="phone" placeholder="e.g., 4165551234" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">1. Select a Date</label>
                        <div id="calendar-container"></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div id="time-slots-wrapper" style="display: none;">
                        <label class="form-label">2. Select an Available Time for <strong id="selected-date-display"></strong></label>
                        <div id="time-slots" class="d-flex flex-wrap gap-2"></div>
                        <div id="no-slots-message" class="text-muted mt-2" style="display: none;"></div>
                    </div>
                </div>
            </div>
            <input type="hidden" id="booking_datetime" name="booking_datetime">
            <button type="submit" id="submitBtn" class="btn btn-primary w-100 mt-3" disabled>Request Booking</button>
        </form>
    </div>
</div>

<?php require_once 'views/templates/footer.php'; ?>
