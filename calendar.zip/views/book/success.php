<?php require_once 'views/templates/header.php'; ?>

<div class="card text-center shadow-sm">
    <div class="card-header bg-success text-white">
        <h2 class="h4 mb-0">Booking Successful!</h2>
    </div>
    <div class="card-body">
        <p class="lead">Your session has been booked successfully.</p>
        <p>Please save your access code. You will need it to view or modify your booking.</p>
        <div class="alert alert-info">
            <h4 class="alert-heading">Your Access Code:</h4>
            <p class="fs-4 fw-bold mb-0"><?php echo htmlspecialchars($accessCode); ?></p>
        </div>
        <a href="/cal/view" class="btn btn-secondary mt-3">View Your Booking</a>
    </div>
</div>

<?php require_once 'views/templates/footer.php'; ?>
