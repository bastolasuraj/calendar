<?php require_once 'views/templates/header.php'; ?>

<div class="card shadow-sm">
    <div class="card-header bg-success text-white">
        <h2 class="h4 mb-0">Your Booking Details</h2>
    </div>
    <div class="card-body">
        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success">Your booking has been updated successfully.</div>
        <?php endif; ?>
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-danger">Could not update your booking. Please try again.</div>
        <?php endif; ?>

        <dl class="row">
            <dt class="col-sm-3">Access Code</dt>
            <dd class="col-sm-9"><?php echo htmlspecialchars($booking['access_code']); ?></dd>

            <dt class="col-sm-3">Email</dt>
            <dd class="col-sm-9"><?php echo htmlspecialchars($booking['email']); ?></dd>

            <dt class="col-sm-3">Laptop Tag</dt>
            <dd class="col-sm-9"><?php echo htmlspecialchars($booking['laptop_tag']); ?></dd>

            <dt class="col-sm-3">Current Booking</dt>
            <dd class="col-sm-9"><?php echo date('F d, Y \a\t g:i A', $booking['booking_datetime']->toDateTime()->getTimestamp()); ?></dd>
        </dl>

        <hr>

        <h3 class="h5 mt-4">Change Booking Time</h3>
        <form action="/cal/view/update" method="POST">
            <input type="hidden" name="access_code" value="<?php echo htmlspecialchars($booking['access_code']); ?>">
            <div class="mb-3">
                <label for="booking_datetime" class="form-label">New Date and Time</label>
                <input type="text" class="form-control datetime-picker" id="booking_datetime" name="booking_datetime" required>
            </div>
            <button type="submit" class="btn btn-primary">Update Booking</button>
            <a href="/cal/view" class="btn btn-secondary">Back to List</a>
        </form>
    </div>
</div>

<?php require_once 'views/templates/footer.php'; ?>
