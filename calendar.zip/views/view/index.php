<?php require_once 'views/templates/header.php'; ?>

<div class="row">
    <div class="col-md-5">
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-info text-white">
                <h2 class="h4 mb-0">View or Edit Your Booking</h2>
            </div>
            <div class="card-body">
                <?php if (isset($_GET['error']) && $_GET['error'] == 'notfound'): ?>
                    <div class="alert alert-warning">Booking not found. Please check your access code.</div>
                <?php endif; ?>
                <form action="/cal/view/find" method="POST">
                    <div class="mb-3">
                        <label for="access_code" class="form-label">Enter Your Access Code</label>
                        <input type="text" class="form-control" id="access_code" name="access_code" required>
                    </div>
                    <button type="submit" class="btn btn-info w-100">Find My Booking</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-7">
        <div class="card shadow-sm">
            <div class="card-header">
                <h2 class="h4 mb-0">Approved Scheduled Sessions</h2>
            </div>
            <div class="card-body">
                <p class="text-muted">Only the first name and time of approved sessions are shown.</p>
                <ul class="list-group">
                    <?php foreach ($publicBookings as $booking): ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><?php echo htmlspecialchars($booking['name']); ?></span>
                            <span class="badge bg-secondary rounded-pill">
                                <?php echo date('M d, Y @ g:i A', $booking['booking_datetime']->toDateTime()->getTimestamp()); ?>
                            </span>
                        </li>
                    <?php endforeach; ?>
                    <?php if (iterator_count($publicBookings) === 0): ?>
                        <li class="list-group-item">No approved sessions booked yet.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php require_once 'views/templates/footer.php'; ?>
