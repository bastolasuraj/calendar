<?php
// Booking model to handle data logic

class Booking {
    private $db;
    private $collection;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->collection = $this->db->bookings;
    }

    // Create a new booking with a 'pending' status
    public function createBooking($laptopTag, $email, $phone, $bookingDateTime) {
        if (empty($laptopTag) || empty($email) || empty($phone) || empty($bookingDateTime) || !$this->isTimeSlotAvailable($bookingDateTime)) {
            return false;
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return false;
        }

        $accessCode = $this->generateAccessCode();
        $name = explode('@', $email)[0];

        $result = $this->collection->insertOne([
            'laptop_tag' => $laptopTag,
            'email' => $email,
            'phone' => $phone, // Add phone number
            'name' => $name,
            'booking_datetime' => new MongoDB\BSON\UTCDateTime(strtotime($bookingDateTime) * 1000),
            'access_code' => $accessCode,
            'status' => 'pending', // Default status
            'created_at' => new MongoDB\BSON\UTCDateTime()
        ]);

        return $result->getInsertedCount() > 0 ? $accessCode : false;
    }

    // Update the status of a booking
    public function updateBookingStatus($accessCode, $status) {
        if (!in_array($status, ['approved', 'rejected'])) {
            return false;
        }

        $result = $this->collection->updateOne(
            ['access_code' => $accessCode],
            ['$set' => ['status' => $status]]
        );

        return $result->getModifiedCount() > 0;
    }

    // Get public bookings that have been approved
    public function getPublicBookings() {
        return $this->collection->find(
            ['status' => 'approved'], // Only show approved bookings
            [
                'projection' => ['name' => 1, 'booking_datetime' => 1],
                'sort' => ['booking_datetime' => 1]
            ]
        );
    }

    // --- Other methods remain the same or have minor changes ---

    private function isHoliday($date) {
        $year = $date->format('Y');
        $dateStr = $date->format('Y-m-d');
        $goodFridays = ['2025-04-18', '2026-04-03', '2027-03-26'];
        if (in_array($dateStr, $goodFridays)) return true;
        $holidays = [
            "$year-01-01", date("Y-m-d", strtotime("third monday of february $year")),
            date('Y-m-d', strtotime("last monday", strtotime("$year-05-25"))), "$year-07-01",
            date("Y-m-d", strtotime("first monday of september $year")), date("Y-m-d", strtotime("second monday of october $year")),
            "$year-12-25", "$year-12-26",
        ];
        $canadaDay = new DateTime("$year-07-01");
        if ($canadaDay->format('N') == 6) { $holidays[] = date('Y-m-d', strtotime("$year-07-03")); }
        elseif ($canadaDay->format('N') == 7) { $holidays[] = date('Y-m-d', strtotime("$year-07-02")); }
        return in_array($dateStr, $holidays);
    }

    public function isTimeSlotAvailable($dateTime) {
        $bookingDateTime = new MongoDB\BSON\UTCDateTime(strtotime($dateTime) * 1000);
        $count = $this->collection->countDocuments(['booking_datetime' => $bookingDateTime, 'status' => 'approved']);
        return $count === 0;
    }

    public function getAvailableSlotsForDate($dateStr) {
        $date = new DateTime($dateStr);
        $dayOfWeek = $date->format('N');
        if ($dayOfWeek >= 6 || $this->isHoliday($date)) { return []; }
        $startTime = new DateTime($dateStr . ' 08:00');
        $endTime = new DateTime($dateStr . ' 17:00');
        $interval = new DateInterval('PT2H');
        $dayStart = new MongoDB\BSON\UTCDateTime(strtotime($dateStr . ' 00:00:00') * 1000);
        $dayEnd = new MongoDB\BSON\UTCDateTime(strtotime($dateStr . ' 23:59:59') * 1000);
        $bookedSlotsCursor = $this->collection->find(
            ['booking_datetime' => ['$gte' => $dayStart, '$lte' => $dayEnd], 'status' => 'approved'],
            ['projection' => ['booking_datetime' => 1]]
        );
        $bookedTimes = [];
        foreach ($bookedSlotsCursor as $booking) { $bookedTimes[] = $booking['booking_datetime']->toDateTime()->format('H:i'); }
        $availableSlots = [];
        $period = new DatePeriod($startTime, $interval, $endTime);
        foreach ($period as $slot) {
            $slotTime = $slot->format('H:i');
            if (!in_array($slotTime, $bookedTimes)) { $availableSlots[] = $slotTime; }
        }
        return $availableSlots;
    }

    private function generateAccessCode($length = 15) {
        return substr(str_shuffle(str_repeat('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/62))), 1, $length);
    }

    public function getAllBookings() {
        return $this->collection->find([], ['sort' => ['created_at' => -1]]);
    }

    public function getBookingByAccessCode($accessCode) {
        return $this->collection->findOne(['access_code' => $accessCode]);
    }

    public function updateBooking($accessCode, $newDateTime) {
        if (empty($accessCode) || empty($newDateTime) || !$this->isTimeSlotAvailable($newDateTime)) { return false; }
        $result = $this->collection->updateOne(
            ['access_code' => $accessCode],
            ['$set' => ['booking_datetime' => new MongoDB\BSON\UTCDateTime(strtotime($newDateTime) * 1000), 'status' => 'pending']] // Reset status on update
        );
        return $result->getModifiedCount() > 0;
    }
}
