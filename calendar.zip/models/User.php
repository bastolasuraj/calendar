<?php
// User model for handling admin registration and login

class User {
    private $db;
    private $collection;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->collection = $this->db->users;
    }

    // Check if any admin user exists
    public function hasAdminUser() {
        return $this->collection->countDocuments() > 0;
    }

    // Create a new admin user
    public function register($email, $password) {
        if (empty($email) || empty($password) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return false;
        }

        // Hash the password for security
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $result = $this->collection->insertOne([
            'email' => $email,
            'password' => $hashedPassword,
            'created_at' => new MongoDB\BSON\UTCDateTime()
        ]);

        return $result->getInsertedCount() > 0;
    }

    // Attempt to log a user in
    public function login($email, $password) {
        $user = $this->collection->findOne(['email' => $email]);

        if ($user && password_verify($password, $user['password'])) {
            return $user; // Password is correct
        }

        return false; // Login failed
    }
}
